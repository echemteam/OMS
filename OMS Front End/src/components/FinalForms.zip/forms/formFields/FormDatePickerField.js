import React from "react";
import "react-datepicker/dist/react-datepicker.css"; // Import the DatePicker CSS
const DatePicker = React.lazy(() =>
  import("../ui/inputs/datePicker/DatePicker")
);

const Label = React.lazy(() => import("../ui/label/Label"));
const ValidationText = React.lazy(() =>
  import("../ui/validation/ValidationText.js")
);

const FormDatePickerFields = ({
  key,
    dataField,
    labelName,
    name,
    type,
    value,
    error,
    formSetting,
    formData,
    overRideProps,
    isRequired,
    fieldSetting,
    onChange,
    onValidation,
    onBlure,
    ...otherProps
}) => {
  const handleDateChange = (date) => {
    if (onChange) {
      onChange(dataField, date);
    }
  };

 
  const handleOnBlur = () => {
    onBlure(dataField)
  };

  return (
    <>
      <div className="date-picker-label-part">
        <>
          <div className="input-label-part">
            {labelName && labelName !== "" && (
              <Label
                labelName={labelName}
                isRequired={isRequired}
              />
            )}
          </div>
          {fieldSetting?.subTittle ?
                <div className={`"section-title" `}>
                    <h5>{fieldSetting.subTittle}</h5>
                </div>
                : ""}
        </>
        <div className="input-date-sec">
        <DatePicker
          label={labelName}
          id={name}
          selected={value}
          name={name}
          placeholder={fieldSetting.placeholder}
          className="datepicker-field"
          onChange={handleDateChange}
          onBlur={handleOnBlur}
          isDisable={
            formSetting?.isViewOnly ||
            fieldSetting?.isDisable ||
            overRideProps?.isDisable
          }
          {...otherProps}
        />
        <ValidationText error={error || ""} />
        </div>
      </div>
    </>
  );
};

export default FormDatePickerFields;
