import React, { lazy } from "react";

const Checkbox = lazy(() => import("../ui/inputs/checkBox/CheckBox"));

const FormCheckboxField = ({
  key,
  dataField,
  labelName,
  name,
  type,
  value,
  error,
  formSetting,
  formData,
  overRideProps,
  isRequired,
  fieldSetting,
  onChange,
  onValidation,
  onBlure,
  ...otherProps
}) => {


  const handleCheckboxChange = (dataField, value) => {
    if (onChange) {
      onChange(dataField, value);
    }
  };

  return (
    <div className="input-field-sec">
      {fieldSetting?.subTittle ?
        <div className={`"section-title" `}>
          <h5>{fieldSetting.subTittle}</h5>
        </div>
        : ""}
      <div className="checkbox-label-part">
        <Checkbox
          name={name}
          label={labelName}
          checked={value}
          isDisable={formSetting?.isViewOnly || fieldSetting?.isDisable || overRideProps?.isDisable}
          dataField={dataField}
          onChange={handleCheckboxChange}
          {...fieldSetting}
        />
      </div>
    </div>
  );
};

export default FormCheckboxField;
