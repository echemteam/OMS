import React, { lazy, useCallback, useMemo, useState } from "react";
import PropTypes from 'prop-types';

import { FormFieldTypes } from "./libs/data/formFieldType";
import { TextInputType } from "./libs/data/formControlTypes";

const Line = lazy(() => import("./ui/separator/Line"));
const FormMainTitle = lazy(() => import("./ui/formTitle/FormMainTitle"));
const FormSelectField = lazy(() => import("./formFields/FormSelectField"));
const FormInputFields = lazy(() => import("./formFields/FormInputFields.js"));
const FormCKEditorField = lazy(() => import("./formFields/FormCKEditorField"));
const FormCheckboxField = lazy(() => import("./formFields/FormCheckBoxFields"));
const FormTextAreaFields = lazy(() => import("./formFields/FormTextAreaField"));
const FormFileUploadField = lazy(() => import("./formFields/FormFileUploadField"));
const FormDatePickerField = lazy(() => import("./formFields/FormDatePickerField"));
const FormRadioButtonField = lazy(() => import("./formFields/FormRadioButtonField"));
const FormMaskInputField = lazy(() => import("./formFields/FormMaskInputField.js"));
const FormEditableSelectField = lazy(() => import("./formFields/FormEditableSelectField"));

const ComponentMap = {
  [FormFieldTypes.INPUT]: FormInputFields,
  [FormFieldTypes.PASSWORD]: FormInputFields,
  [FormFieldTypes.NUMERIC]: FormInputFields,
  [FormFieldTypes.MASKINPUT]: FormMaskInputField,
  [FormFieldTypes.TEXTAREA]: FormTextAreaFields,
  [FormFieldTypes.CHECKBOX]: FormCheckboxField,
  [FormFieldTypes.RADIOBUTTON]: FormRadioButtonField,
  [FormFieldTypes.DATEPICKER]: FormDatePickerField,
  [FormFieldTypes.SELECT]: FormSelectField,
  [FormFieldTypes.TEXTEDITOR]: FormCKEditorField,
  [FormFieldTypes.FILE]: FormFileUploadField,
  [FormFieldTypes.EDITABLEDROPDOWN]: FormEditableSelectField,
  [FormFieldTypes.SEPARATOR]: Line,
  [FormFieldTypes.MAINFORMTITLE]: FormMainTitle,
};



const FormFields = ({
  fields,
  sections,
  formData,
  validState,
  onFormStateChange,
  onUpdateValidation,
  formSetting,
  onActionChange,
  onFormFieldChange,
  onFieldBlure,
  fieldValiadtionRules
}) => {

  console.log("section",sections);

  const [overRideProps, setOverRideProps] = useState({});

  const handleInputChange = (dataField, value) => {
    let updatedData = { ...formData, [dataField]: value };
    updatedData = stateChangeAction(dataField, updatedData);
    onFormStateChange?.(updatedData);
    onFormFieldChange?.(dataField, updatedData);
  };


  const handleBlure = (dataField) => {
    let updatedData = { ...formData };

    if (onUpdateValidation) {
      onUpdateValidation(dataField);
    }
    onFieldBlure?.(dataField, updatedData);
  };



  const stateChangeAction = (dataField, updatedState) => {
    const formField = memoizedSelectFormField(sections, dataField);

    formField?.changeAction?.resetValue?.forEach(({ dataField, value }) => {
      if (dataField && value) {
        updatedState[dataField] = value;
      }
    });

    if (formField?.changeAction?.resetFieldSetting?.length > 0) {
      let newOverRideProps = { ...overRideProps };

      formField.changeAction.resetFieldSetting.forEach(({ dependancyField: dependancyFields, condition }) => {
        const isConditionMet = condition.type === "=" && updatedState[dataField] === condition.value;

        if (Array.isArray(dependancyFields)) {
          dependancyFields.forEach(({ dataField, updateProps, resetValue }) => {
            if (isConditionMet) {
              newOverRideProps[dataField] = { ...updateProps };
              updatedState[dataField] = resetValue;
            } else {
              delete newOverRideProps[dataField];
            }
          });
        }
      });

      setOverRideProps(newOverRideProps);
    }

    return updatedState;
  };


  const memoizedSelectFormField = useCallback((sections, dataField) => {
    const searchFields = (fields, dataField) => {
      for (const field of fields) {
        if (field.dataField === dataField) {
          return field;
        }
      }
      return null;
    };

    for (const section of sections) {
      const foundField = searchFields(section.fields, dataField);
      if (foundField) {
        return foundField;
      }
    }
    
    return null;
  }, [sections]);

  const renderField = (field, index) => {
    const { containerCss = "col-md-6" } = field.style || {};
    const isRequired = fieldValiadtionRules?.[field.dataField]?.length > 0;
  
    const commonProps = {
      key: `${field.dataField}_${index}`,
      dataField: field.dataField,
      labelName: field.label,
      name: field.id,
      type: fieldTypeToInputType(field.fieldType),
      value: formData?.[field.dataField] || "",
      error: validState.error[field.dataField] || "",
      formSetting,
      formData,
      changeAction: field.changeAction,
      overRideProps: overRideProps?.[field.dataField],
      isRequired,
      fieldSetting: field.fieldSetting,
      onChange: handleInputChange,
      onValidation: onUpdateValidation,
      onBlure: handleBlure,
    };
  
    const FieldComponent = ComponentMap[field.fieldType];
  
    if (!FieldComponent) return null;
  
    if (field.fieldType === FormFieldTypes.SEPARATOR) {
      return <FieldComponent containerCss={containerCss} key={field.dataField} />;
    }
  
    if (field.fieldType === FormFieldTypes.MAINFORMTITLE) {
      return <FieldComponent {...field.fieldSetting} containerCss={containerCss} />;
    }
  
    return (
      <div className={containerCss} key={field.dataField}>
        <FieldComponent {...commonProps} options={field.fieldSetting?.options} />
      </div>
    );
  };

  const renderSection = (section, index) => {
    const { sectionStyle = "col-md-12" } = section.style || {};
  const Wrapper = section.wrapperTemplate || React.Fragment;
debugger;
  const isJSXLiteral = React.isValidElement(Wrapper);

  return (
    <div className={sectionStyle} key={`section_${index}`}>
      {isJSXLiteral ? (
        React.cloneElement(Wrapper, {}, section.fields.map(renderField))
      ) : (
        <Wrapper>
          {section.fields.map(renderField)}
        </Wrapper>
      )}
    </div>
  );
    
  };

  return (
    <>
    {
      
      sections.map(renderSection)
    }
    </>
  );
};

const fieldTypeToInputType = (fieldtype) => {
  switch (fieldtype) {
    case FormFieldTypes.PASSWORD:
      return TextInputType.PASSWORD;
    case FormFieldTypes.NUMERIC:
      return TextInputType.NUMBER;
    case FormFieldTypes.CHECKBOX:
      return TextInputType.CHECKBOX;
    case FormFieldTypes.EDITABLEDROPDOWN:
      return TextInputType.TEXT;
    case FormFieldTypes.DATEPICKER:
      return TextInputType.DATEPICKER;
    case FormFieldTypes.TEXTAREA:
      return TextInputType.TEXT;
    case FormFieldTypes.TEXTEDITOR:
      return TextInputType.TEXT;
    case FormFieldTypes.FILE:
      return TextInputType.FILE;
    case FormFieldTypes.RADIOBUTTON:
      return TextInputType.RADIO;
    default:
      return TextInputType.TEXT;
  }
};
export default FormFields;


FormFields.propTypes = {
  // Array of field objects to render
  fields: PropTypes.array.isRequired,

  // Object containing form data values
  formData: PropTypes.object.isRequired,

  // Object containing validation states
  validState: PropTypes.object.isRequired,

  // Function to handle form state changes
  onFormStateChange: PropTypes.func,

  // Function to handle validation updates
  onUpdateValidation: PropTypes.func,

  // Object with form settings and configurations
  formSetting: PropTypes.object,

  // Function to handle field-specific actions
  onActionChange: PropTypes.func,

  // Function to handle individual form field changes
  onFormFieldChange: PropTypes.func,

  // Function to handle key press events
  onKeyPress: PropTypes.func,
};