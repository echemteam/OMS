

import React from 'react';
import PropTypes from 'prop-types';

import ReactDatePicker from "react-datepicker";

import "react-datepicker/dist/react-datepicker.css";
import "bootstrap-daterangepicker/daterangepicker.css";
import "./DatePicker.scss"
import "./DateRange.scss";

const DatePickerComponent = ({
    label,
    value,
    onChange,
    placeholder,
    onBlur,
    disabled,
    selected,
    inputFormat
}) => {

    const handleDateChange = (newValue) => {
        if (onChange) {
            onChange(newValue);
        }
    };

    return (
        <div className="date-picker">
            <ReactDatePicker
                placeholderText={placeholder}
                selected={selected}
                onChange={(e) => handleDateChange(e)}
                onBlur={onBlur}
                autoComplete="off"
                disabled={disabled}
            />
        </div>
    );
};

DatePickerComponent.propTypes = {
    label: PropTypes.string.isRequired,
    value: PropTypes.instanceOf(Date),
    onChange: PropTypes.func.isRequired,
    placeholder: PropTypes.string,
    onBlur: PropTypes.func,
    disabled: PropTypes.bool,
    selected: PropTypes.instanceOf(Date),
};

export default DatePickerComponent;