import React, { useEffect, useRef, useState } from "react";
import PropTypes from "prop-types";
import "./FileUpload.scss";
import { IconButton } from "@mui/material";
import PhotoCamera from '@mui/icons-material/CameraEnhance';
import DeleteIcon from '@mui/icons-material/Delete';

const FileUpload = ({
  name = "",
  filename,
  onChange,
  onClear,
  acceptedFiles,
}) => {
  const [fileValue, setFileValue] = useState(null);
  const [filePreview, setFilePreview] = useState();
  const fileRef = useRef();

  const handleInputChange = (e) => {
    if (onChange) {
      onChange(e);
    }
    const reader = new FileReader();
    reader.readAsDataURL(e.target.files[0]);
    reader.onload = (_event) => {
      setFilePreview(reader.result);
    };
  };

  const handleClearClick = () => {
    if (onClear) {
      fileRef.current.value = null;
      setFileValue(null);
      onClear();
    }
  };

  useEffect(() => {
    if (filename && typeof filename === "object") {
      setFileValue(filename.name || filename.fileName);
    } else if (filename) {
      setFileValue(filename);
      setFilePreview(filename);
    } else {
      setFileValue(null);
      fileRef.current.value = null;
      handleClearClick();
    }
  }, [filename]);

  return (
    <div className="file-upload-container">
      <input
        ref={fileRef}
        id={name}
        name={name}
        type="file"
        className="file-input"
        onChange={handleInputChange}
        accept={acceptedFiles}
      />
      <div className="upload-box">
        {!fileValue ? (
          <>
            <div className="upload-border">
              <div className="upload-group">
                <div className="upload-icon">
                  <IconButton color="primary" component="span">
                    <PhotoCamera />
                  </IconButton>
                </div>
                <p className="upload-text">Upload photo</p>
              </div>
            </div>
            <p className="file-info">
              Allowed *.jpeg, *.jpg, *.png, *.gif max size of 3 Mb
            </p>
          </>
        ) : (
          <div className="image-preview">
            <img src={filePreview} alt="Uploaded File" />
            <button className="clear-button" onClick={handleClearClick}>
              <DeleteIcon/>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

FileUpload.propTypes = {
  name: PropTypes.string,
  filename: PropTypes.oneOfType([PropTypes.string, PropTypes.object]),
  onChange: PropTypes.func.isRequired,
  onClear: PropTypes.func,
  acceptedFiles: PropTypes.string,
};

export default FileUpload;
